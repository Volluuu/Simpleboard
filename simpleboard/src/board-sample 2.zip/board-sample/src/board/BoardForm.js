import React from "react";

function BoardForm(props) {
  return (
    <div>
      <h1>BoardForm</h1>
    </div>
  );
}

export default BoardForm;
