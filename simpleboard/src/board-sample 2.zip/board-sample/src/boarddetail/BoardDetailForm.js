import React from "react";

function BoardDetailForm(props) {
  return (
    <div>
      <h1>board detail</h1>
    </div>
  );
}

export default BoardDetailForm;
